/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import model.Colaborador;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


/**
 *
 * @author Fernando Marcelo
 */
public class LectorArchivo {

    public static ArrayList<Colaborador> cargarColaboradores(String rutaArchivo) {
        ArrayList<Colaborador> lista = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            int numeroLinea = 0;

            while ((linea = br.readLine()) != null) {
                numeroLinea++;
                if (linea.trim().isEmpty()) continue;

                try {
                    String[] datos = linea.split(";");
                    if (datos.length != 5) {
                        System.out.println("Advertencia en línea " + numeroLinea + ": formato incorrecto.");
                        continue;
                    }

                    String rut = datos[0].trim();
                    String nombre = datos[1].trim();
                    String rol = datos[2].trim();
                    String especialidad = datos[3].trim();
                    double tarifa = Double.parseDouble(datos[4].trim());

                    Colaborador colab = new Colaborador(rut, nombre, rol, especialidad, tarifa);
                    lista.add(colab);

                } catch (NumberFormatException e) {
                    System.out.println("Error de formato numérico en línea " + numeroLinea + ": " + e.getMessage());
                }
            }
            System.out.println("Carga finalizada: " + lista.size() + " registros importados correctamente.\n");

        } catch (IOException e) {
            System.out.println("Error crítico al leer el archivo '" + rutaArchivo + "': " + e.getMessage());
        }

        return lista;
    }
    
}
