/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app;

import model.Colaborador;
import service.GestorColaboradores;
import util.LectorArchivo;

import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author Fernando Marcelo
 */
public class Main {
    public static void main(String[] args) {
        GestorColaboradores gestor = new GestorColaboradores();
        Scanner scanner = new Scanner(System.in);

        // 1. Carga automática desde archivo externo al iniciar
        ArrayList<Colaborador> datosArchivo = LectorArchivo.cargarColaboradores("src/colaboradores/colaboradores"); gestor.cargarLista(datosArchivo);

        int opcion = 0;
        do {
            System.out.println("=== SISTEMA DE GESTIÓN - LLANQUIHUE TOUR ===");
            System.out.println("1. Mostrar todos los colaboradores");
            System.out.println("2. Buscar colaborador por RUT");
            System.out.println("3. Filtrar por Rol (Guía, Operador, Proveedor)");
            System.out.println("4. Registrar nuevo colaborador manualmente");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());

                switch (opcion) {
                    case 1:
                        gestor.listarTodos();
                        break;
                    case 2:
                        System.out.print("Ingrese el RUT a buscar (ej. 15.432.111-9): ");
                        String rut = scanner.nextLine();
                        Colaborador encontrado = gestor.buscarPorRut(rut);
                        if (encontrado != null) {
                            System.out.println("Encontrado -> " + encontrado + "\n");
                        } else {
                            System.out.println("No se encontró ningún registro con ese RUT.\n");
                        }
                        break;
                    case 3:
                        System.out.print("Ingrese rol a filtrar (ej. Guia, Operador, Proveedor): ");
                        String rol = scanner.nextLine();
                        gestor.filtrarPorRol(rol);
                        break;
                    case 4:
                        System.out.print("RUT: ");
                        String nuevoRut = scanner.nextLine();
                        System.out.print("Nombre: ");
                        String nuevoNombre = scanner.nextLine();
                        System.out.print("Rol: ");
                        String nuevoRol = scanner.nextLine();
                        System.out.print("Especialidad: ");
                        String nuevaEsp = scanner.nextLine();
                        System.out.print("Tarifa diaria: ");
                        double nuevaTarifa = Double.parseDouble(scanner.nextLine());

                        Colaborador nuevo = new Colaborador(nuevoRut, nuevoNombre, nuevoRol, nuevaEsp, nuevaTarifa);
                        if (gestor.agregarColaborador(nuevo)) {
                            System.out.println("Colaborador agregado exitosamente.\n");
                        }
                        break;
                    case 5:
                        System.out.println("Cerrando sistema Llanquihue Tour...");
                        break;
                    default:
                        System.out.println("Opción inválida. Intente entre 1 y 5.\n");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Debe ingresar un valor numérico válido.\n");
            }
        } while (opcion != 5);

        scanner.close();
    }
    
}
