/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Fernando Marcelo
 */
public class Colaborador extends Persona {
    private String rol; // Ej: Guía Turístico, Operador Local, Proveedor Transporte
    private String especialidad;
    private double tarifaDiaria;

    public Colaborador() {
        super();
    }

    public Colaborador(String rut, String nombre, String rol, String especialidad, double tarifaDiaria) {
        super(rut, nombre);
        this.rol = rol;
        this.especialidad = especialidad;
        this.tarifaDiaria = tarifaDiaria;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public double getTarifaDiaria() {
        return tarifaDiaria;
    }

    public void setTarifaDiaria(double tarifaDiaria) {
        this.tarifaDiaria = tarifaDiaria;
    }

    @Override
    public String toString() {
        return "Colaborador{" + "rol=" + rol + ", especialidad=" + especialidad + ", tarifaDiaria=" + tarifaDiaria + '}';
    }
    
    
    
}
