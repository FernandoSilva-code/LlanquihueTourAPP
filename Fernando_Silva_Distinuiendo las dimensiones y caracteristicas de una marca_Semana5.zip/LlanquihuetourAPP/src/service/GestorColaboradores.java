/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import model.Colaborador;
import java.util.ArrayList;



/**
 *
 * @author Fernando Marcelo
 */
public class GestorColaboradores {
    private ArrayList<Colaborador> colaboradores;

    public GestorColaboradores() {
        this.colaboradores = new ArrayList<>();
    }

    public void cargarLista(ArrayList<Colaborador> listaImportada) {
        for (Colaborador c : listaImportada) {
            agregarColaborador(c);
        }
    }

    // Evita duplicaciones por RUT (requisito de la problemática)
    public boolean agregarColaborador(Colaborador nuevo) {
        if (buscarPorRut(nuevo.getRut()) != null) {
            System.out.println("Registro duplicado omitido (RUT ya existe): " + nuevo.getRut());
            return false;
        }
        colaboradores.add(nuevo);
        return true;
    }

    public void listarTodos() {
        if (colaboradores.isEmpty()) {
            System.out.println("No hay colaboradores registrados.");
            return;
        }
        System.out.println("=== LISTADO DE COLABORADORES LLANQUIHUE TOUR ===");
        for (Colaborador c : colaboradores) {
            System.out.println(c.toString());
        }
        System.out.println("=================================================\n");
    }

    public Colaborador buscarPorRut(String rut) {
        for (Colaborador c : colaboradores) {
            if (c.getRut().equalsIgnoreCase(rut.trim())) {
                return c;
            }
        }
        return null;
    }

    public void filtrarPorRol(String rolBuscado) {
        System.out.println("--- Resultados para el rol: " + rolBuscado + " ---");
        boolean encontrado = false;
        for (Colaborador c : colaboradores) {
            if (c.getRol().toLowerCase().contains(rolBuscado.toLowerCase().trim())) {
                System.out.println(c.toString());
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontraron registros con ese rol.");
        }
        System.out.println();
    }
    
}
